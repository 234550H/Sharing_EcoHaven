import React from 'react';
import '../src/assets/style/frontend/footer.css'; 

export default function Footer() {
  return (
    <footer className="footer-container">
      <div className="footer-content">
        <div className="col1">
          <h6 className="footer-title">Overview</h6>
          <ul className="nav flex-column">
            <li className="nav-item">
              <a className="nav-link" href="#">About us</a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">Workshops</a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">Events</a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">Rewards</a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">Contact Us</a>
            </li>
          </ul>
        </div>
        <div className="col2">
          <h6 className="footer-title">Helps & FAQS</h6>
          <ul className="nav flex-column">
            <li className="nav-item">
              <a className="nav-link" href="#">FAQs</a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">Payment Methods</a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">Refunds</a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">Terms & Conditions</a>
            </li>
          </ul>
        </div>
        <div className="col3">
          <div className="newsletter-form">
        <h6 className="footer-title">Subscribe to new Eco-related events:</h6>
        <p style={{color:'white',marginRight:'4px',paddingRight:'70px'}}>Be the first to receive the newest event and learn more about our Eco-world!</p>
        <form>
          <input type="email"  placeholder="Your Email" style={{width:'300px',marginLeft:'-110px'}}/>
          <button type="submit" className="subcribe_btn" >Subscribe</button>
        </form>
         <a href='https://www.facebook.com/MSEsingapore/' target="_blank"><img src='../src/assets/icons/facebook.png' alt='facebook'   className="social" style={{marginRight:'300px'}}/></a>
          <a href='https://www.instagram.com/msesingapore/' target="_blank" ><img src='../src/assets/icons/instagram.png' alt='instagram' className="social" /></a>

        </div>
</div>
      </div>
      <div className="copyrighttext">
        <p style={{color:'white'}}>© 2024 EcoHaven</p>
      </div>
    </footer>
  );
}