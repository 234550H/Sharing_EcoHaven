import React from 'react';
import '../src/assets/style/frontend/navbar.css';

function Navbar() {

  return (
    <ul className="navbar">
      <li className="logo">
        <a href="#home" className="ecohaven">
          <span className="eco">Eco</span>Haven
        </a>
      </li>
   {/*Navigation header*/ }
      <div className="menu">
        <li><a href="#aboutUs">About Us</a></li>
        <li><a href="#event">Events</a></li>
        <li><a href="#bookNow">Book Now</a></li>
        <li><a href="#rewards">Rewards</a></li>
        <li><a href="#contactUs">Contact Us</a></li>
      </div>
   {/*search bar */ }
      <div className="actions">
        <div class="search-container">
    <input class="search-input" type="search" placeholder="Search" aria-label="Search"/>
    <button class="search-button" type="submit">Search</button>
 <a href="#login">
            <button type="button" className="btn btn-primary login-button" data-mdb-ripple-init>Get Started</button>
          </a>
</div>
</div>
    </ul>
  );
}

export default Navbar;
