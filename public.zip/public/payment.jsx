import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { loadStripe } from '@stripe/stripe-js';

const stripePromise = loadStripe('your-publishable-key'); // Replace with your Stripe publishable key

const PaymentPage = () => {
  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [homeAddress, setHomeAddress] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [amount, setAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [cardDetails, setCardDetails] = useState('');
  const [name, setName] = useState('');
  const [expiryMonth, setExpiryMonth] = useState('');
  const [expiryYear, setExpiryYear] = useState('');
  const [cvv, setCvv] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
    const stripe = await stripePromise;
    const elements = stripe.elements();
    const cardElement = elements.create('card');
    cardElement.mount('#card-element');

    const { token, error } = await stripe.createToken(cardElement, {
      name: email,
      address_line1: homeAddress,
      address_zip: postalCode,
    });

    if (error) {
      setMessage(error.message);
    } else {
      const response = await fetch('http://localhost:5000/api/payments/stripe-payment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount,
          email,
          phoneNumber,
          homeAddress,
          postalCode,
          paymentMethod,
          token: token.id,
        }),
      });

      const result = await response.json();
      if (result.error) {
        setMessage(result.error);
      } else {
        setMessage('Payment successful!');
      }
    }
  };

  return (
    <div className="container mt-5">
      <h1 className="text-center">Payment Details</h1>
      <form id="payment-form" className="mt-4" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="email">Email Address:</label>
          <input
            type="email"
            className="form-control"
            id="email"
            name="email"
            placeholder="E.g. Potato@gmail.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="phone">Phone Number:</label>
          <input
            type="text"
            className="form-control"
            id="phone"
            name="phone"
            placeholder="1234 5678"
            value={phoneNumber}
            onChange={(e) => setPhoneNumber(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="address">Address:</label>
          <input
            type="text"
            className="form-control"
            id="address"
            name="address"
            placeholder="[Insert home address]"
            value={homeAddress}
            onChange={(e) => setHomeAddress(e.target.value)}
            required
          />
        </div>
        <h2 className="mt-4">Payment Method</h2>
        <div className="form-group">
          <div className="form-check">
            <input
              className="form-check-input"
              type="radio"
              id="card"
              name="paymentMethod"
              value="card"
              checked={paymentMethod === 'card'}
              onChange={() => setPaymentMethod('card')}
            />
            <label className="form-check-label" htmlFor="card">
              Credit/Debit Card
            </label>
            <img
              src="https://seeklogo.com/images/V/VISA-logo-16F4F82D13-seeklogo.com.png"
              alt="VISA Logo"
              height="12px"
              width="35px"
            />
          </div>
          <div className="form-check">
            <input
              className="form-check-input"
              type="radio"
              id="paypal"
              name="paymentMethod"
              value="paypal"
              checked={paymentMethod === 'paypal'}
              onChange={() => setPaymentMethod('paypal')}
            />
            <label className="form-check-label" htmlFor="paypal">
              PayPal
            </label>
            <img
              src="https://i.pcmag.com/imagery/reviews/068BjcjwBw0snwHIq0KNo5m-15.fit_lim.size_1050x591.v1602794215.png"
              alt="PayPal Logo"
              height="30px"
              width="55px"
            />
          </div>
          <div className="form-check">
            <input
              className="form-check-input"
              type="radio"
              id="paylater"
              name="paymentMethod"
              value="paylater"
              checked={paymentMethod === 'paylater'}
              onChange={() => setPaymentMethod('paylater')}
            />
            <label className="form-check-label" htmlFor="paylater">
              PayLater
            </label>
          </div>
        </div>
        <div className="form-group">
          <label htmlFor="credit">Credit Card Number:</label>
          <input
            type="text"
            className="form-control"
            id="credit"
            name="credit"
            placeholder="1234 1234 1234 1234"
            value={cardDetails}
            onChange={(e) => setCardDetails(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="name">Full Name:</label>
          <input
            type="text"
            className="form-control"
            id="name"
            name="name"
            placeholder="Bob Thng Yi Rui"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="expiry">Expiry Date:</label>
          <div className="d-flex">
            <input
              type="text"
              className="form-control mr-2"
              name="month"
              placeholder="MM"
              maxlength="2"
              size="2"
              value={expiryMonth}
              onChange={(e) => setExpiryMonth(e.target.value)}
              required
            />
            <span>/</span>
            <input
              type="text"
              className="form-control ml-2"
              name="year"
              placeholder="YY"
              maxlength="2"
              size="2"
              value={expiryYear}
              onChange={(e) => setExpiryYear(e.target.value)}
              required
            />
          </div>
        </div>
        <div className="form-group">
          <label htmlFor="cvv">CVV:</label>
          <input
            type="text"
            className="form-control"
            id="cvv"
            name="cvv"
            placeholder="432"
            value={cvv}
            onChange={(e) => setCvv(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary btn-block">Pay</button>
      </form>
      {message && <div className="alert alert-info mt-4">{message}</div>}
    </div>
  );
};

export default PaymentPage;
