import React from 'react';

const PaymentCompletePage = () => {
  return (
    <div>
      <p>Payment complete</p>
    </div>
  );
};

export default PaymentCompletePage;
