import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const RefundPage = () => {
  const [paymentId, setPaymentId] = useState('');
  const [refundAmount, setRefundAmount] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();

    const response = await fetch('http://localhost:5000/api/payments/refund', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        paymentId,
        amount: refundAmount,
      }),
    });

    const result = await response.json();
    if (result.error) {
      setMessage(result.error);
    } else {
      setMessage('Refund processed successfully!');
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center">Refund Page</h2>
      <form id="refund-form" className="mt-4" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="paymentId">Payment ID</label>
          <input
            type="text"
            className="form-control"
            id="paymentId"
            placeholder="Enter Payment ID"
            value={paymentId}
            onChange={(e) => setPaymentId(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="refundAmount">Refund Amount</label>
          <input
            type="number"
            className="form-control"
            id="refundAmount"
            placeholder="Enter refund amount"
            value={refundAmount}
            onChange={(e) => setRefundAmount(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary btn-block">Request Refund</button>
      </form>
      {message && <div id="refund-result" className="mt-3 alert alert-info">{message}</div>}
    </div>
  );
};

export default RefundPage;
