const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const logger = require('morgan');
require('dotenv').config();
const paymentRoute = require('./routes/payment');

const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(logger('dev'));
app.use(cors({
    origin: process.env.CLIENT_URL
}));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// Serve static files from the "client1/public" directory
app.use(express.static(__dirname + '/../client1/public'));

// Simple Route
app.get("/", (req, res) => {
    res.send("Welcome to the EcoHaven.");
});

// Payment Routes
app.use('/api/payments', paymentRoute);

const db = require('./models');
db.sequelize.sync({ alter: true })
    .then(() => {
        app.listen(port, () => {
            console.log(`⚡ Server running on http://localhost:${port}`);
        });
    })
    .catch((err) => {
        console.log(err);
    });