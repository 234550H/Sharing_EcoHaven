// mockPayment.js
module.exports.processPayment = async (paymentData) => {
    const { amount, email, phoneNumber, homeAddress, postalCode, paymentMethod, cardNumber, expiryDate, cvv } = paymentData;

    // Simulate payment processing logic
    console.log('Processing payment with the following data:', paymentData);

    // Simulate a delay for payment processing
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Simulate a successful payment response
    return {
        success: true,
        message: 'Payment processed successfully',
        chargeId: 'mock_charge_id_123456',
        customerId: 'mock_customer_id_123456'
    };
};
