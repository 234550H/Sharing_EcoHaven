// paypal.js
const paypal = require('@paypal/checkout-server-sdk');

// Create an environment
let clientId = process.env.PAYPAL_CLIENT_ID;
let clientSecret = process.env.PAYPAL_CLIENT_SECRET;
let environment = new paypal.core.SandboxEnvironment(clientId, clientSecret);
let client = new paypal.core.PayPalHttpClient(environment);

async function createOrder(amount, currency) {
  const request = new paypal.orders.OrdersCreateRequest();
  request.requestBody({
    intent: 'CAPTURE',
    purchase_units: [{
      amount: {
        currency_code: currency,
        value: amount
      }
    }]
  });

  try {
    const order = await client.execute(request);
    return order;
  } catch (err) {
    console.error(err);
    throw err;
  }
}

module.exports = { createOrder };
