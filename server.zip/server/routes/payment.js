const express = require('express');
const router = express.Router();
const Payment = require('../models').Payment;
const { processPayment } = require('../mockpayment');

// Create Payment
router.post("/payment", async (req, res) => {
    const { amount, email, phoneNumber, homeAddress, postalCode, paymentMethod, cardNumber, expiryDate, cvv } = req.body;

    try {
        const paymentData = {
            amount,
            email,
            phoneNumber,
            homeAddress,
            postalCode,
            paymentMethod,
            cardNumber,
            expiryDate,
            cvv
        };

        const paymentResult = await processPayment(paymentData);

        if (paymentResult.success) {
            // Save payment details to the database
            await Payment.create({
                amount: amount,
                email: email,
                phoneNumber: phoneNumber,
                homeAddress: homeAddress,
                postalCode: postalCode,
                paymentMethod: paymentMethod,
                currency: "USD",
                customerId: paymentResult.customerId,
                chargeId: paymentResult.chargeId
            });

            res.status(200).send({ message: paymentResult.message });
        } else {
            res.status(500).send({ error: 'Payment failed' });
        }
    } catch (err) {
        console.error(err);
        res.status(500).send({ error: 'Payment failed' });
    }
});

// Get All Payments
router.get("/payment", async (req, res) => {
    try {
        const payments = await Payment.findAll();
        res.status(200).json(payments);
    } catch (err) {
        console.error(err);
        res.status(500).send({ error: 'Failed to retrieve payments' });
    }
});

// Get Payment by ID
router.put("/:id", async (req, res) => {
    const { id } = req.params; // Ensure the ID is extracted from the URL parameters
    const { amount, email, phoneNumber, homeAddress, postalCode, paymentMethod, cardNumber, expiryDate, cvv, currency, customerId, chargeId } = req.body;

    try {
        const payment = await Payment.findByPk(id);
        if (!payment) {
            return res.status(404).send({ error: 'Payment not found' });
        }

        await payment.update({ amount, email, phoneNumber, homeAddress, postalCode, paymentMethod, cardNumber, expiryDate, cvv, currency, customerId, chargeId });
        res.status(200).json(payment);
    } catch (err) {
        console.error(err);
        res.status(500).send({ error: 'Failed to update payment' });
    }
});

// Update Payment by ID
router.put("/:id", async (req, res) => {
    const { id } = req.params;
    const { amount, email, phoneNumber, homeAddress, postalCode, paymentMethod, cardNumber, expiryDate, cvv, currency, customerId, chargeId } = req.body;

    try {
        console.log(`Received PUT request for payment ID: ${id}`);

        const payment = await Payment.findByPk(id);
        if (!payment) {
            console.log(`Payment with ID ${id} not found`);
            return res.status(404).send({ error: 'Payment not found' });
        }

        console.log(`Found payment: ${JSON.stringify(payment)}`);

        await payment.update({ amount, email, phoneNumber, homeAddress, postalCode, paymentMethod, cardNumber, expiryDate, cvv, currency, customerId, chargeId });
        res.status(200).json(payment);
    } catch (err) {
        console.error(`Error updating payment with ID ${id}:`, err);
        res.status(500).send({ error: 'Failed to update payment' });
    }
});

// Delete Payment by ID
router.delete("/:id", async (req, res) => {
    const { id } = req.params;

    try {
        console.log(`Received DELETE request for payment ID: ${id}`);

        const payment = await Payment.findByPk(id);
        if (!payment) {
            console.log(`Payment with ID ${id} not found`);
            return res.status(404).send({ error: 'Payment not found' });
        }

        await payment.destroy();
        res.status(200).send({ message: 'Payment deleted successfully' });
    } catch (err) {
        console.error(`Error deleting payment with ID ${id}:`, err);
        res.status(500).send({ error: 'Failed to delete payment' });
    }
});
    
router.post("/refund", async (req, res) => {
    const { paymentId, amount } = req.body;

    try {
        // Assume you store the Stripe charge ID in the Payment record
        const payment = await Payment.findByPk(paymentId);
        if (!payment) {
            return res.status(404).send({ error: 'Payment not found' });
        }

        const refund = await stripe.refunds.create({
            charge: payment.chargeId,
            amount: amount * 100 // Amount in cents
        });

        res.status(200).send(refund);
    } catch (err) {
        console.error(err);
        res.status(500).send({ error: 'Failed to process refund' });
    }
});
module.exports = router;
