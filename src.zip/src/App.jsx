import React from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import PaymentPage from "./components/PaymentPage";
import SuccessPage from "./components/SuccessPage";

const App = () => (
  <Router>
    <Switch>
      <Route exact path="/" element={PaymentPage} />
      <Route path="/success" element={SuccessPage} />
      <Route path="/paymentpage" element={PaymentPage} />
    </Switch>
  </Router>
);

export default App;