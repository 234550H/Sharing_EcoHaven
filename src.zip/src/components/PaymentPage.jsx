// src/PaymentForm.js
import React, { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import './PaymentForm.css'; // Create this CSS file based on the styles provided

const stripePromise = loadStripe('your-publishable-key'); // Replace with your Stripe publishable key

const PaymentForm = () => {
  const stripe = useStripe();
  const elements = useElements();

  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [homeAddress, setHomeAddress] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [amount, setAmount] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    const cardElement = elements.getElement(CardElement);

    const { token, error } = await stripe.createToken(cardElement, {
      name: email,
      address_line1: homeAddress,
      address_zip: postalCode
    });

    if (error) {
      setMessage(error.message);
    } else {
      const response = await fetch('http://localhost:5000/api/payments/stripe-payment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          amount: amount,
          email: email,
          phoneNumber: phoneNumber,
          homeAddress: homeAddress,
          postalCode: postalCode,
          paymentMethod: 'Debit/Credit Card',
          token: token.id // Send the token ID to your server
        })
      });

      const result = await response.json();
      if (result.error) {
        setMessage(result.error);
      } else {
        setMessage('Payment successful!');
      }
    }
  };

  return (
    <form id="payment-form" onSubmit={handleSubmit}>
      <input
        type="email"
        id="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
      />
      <input
        type="text"
        id="phoneNumber"
        placeholder="Phone Number"
        value={phoneNumber}
        onChange={(e) => setPhoneNumber(e.target.value)}
        required
      />
      <input
        type="text"
        id="homeAddress"
        placeholder="Home Address"
        value={homeAddress}
        onChange={(e) => setHomeAddress(e.target.value)}
        required
      />
      <input
        type="text"
        id="postalCode"
        placeholder="Postal Code"
        value={postalCode}
        onChange={(e) => setPostalCode(e.target.value)}
        required
      />
      <input
        type="number"
        id="amount"
        placeholder="Amount"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
        required
      />
      <div id="card-element">
        <CardElement />
      </div>
      <button type="submit" disabled={!stripe}>
        Pay
      </button>
      <div id="payment-result">{message}</div>
    </form>
  );
};

const WrappedPaymentForm = () => (
  <Elements stripe={stripePromise}>
    <PaymentForm />
  </Elements>
);

export default WrappedPaymentForm;
