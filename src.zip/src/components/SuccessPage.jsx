import React from 'react';
import { useLocation } from 'react-router-dom';

const SuccessPage = () => {
  const location = useLocation();
  const { paymentData, response } = location.state || {};

  return (
    <div>
      <h1>Payment Successful</h1>
      <h2>Payment Details:</h2>
      <p><strong>Email:</strong> {paymentData.email}</p>
      <p><strong>Phone:</strong> {paymentData.phone}</p>
      <p><strong>Address:</strong> {paymentData.address}</p>
      <p><strong>Payment Method:</strong> {paymentData.paymentMethod}</p>
      <h2>Response from Payment Gateway:</h2>
      <pre>{JSON.stringify(response, null, 2)}</pre>
    </div>
  );
};

export default SuccessPage;